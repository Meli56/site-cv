<?php

interface Controller
{
    public function handle($request);
}