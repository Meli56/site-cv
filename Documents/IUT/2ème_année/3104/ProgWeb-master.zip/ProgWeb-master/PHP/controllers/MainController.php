<?php
require('Controller.php');

class MainController implements Controller
{
    public function handle($request)
    {
        // TODO: Implement handle() method.
    }
}