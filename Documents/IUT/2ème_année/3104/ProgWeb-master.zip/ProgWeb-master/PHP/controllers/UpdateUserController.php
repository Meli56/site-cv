<?php
require_once "Controller.php";
class UpdateUserController implements Controller
{
    public function handle($request)
    {
        // TODO: Implement handle() method.
    }
}