<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>SportTrack | Page Not Found</title>
    <link  rel="stylesheet" href="./public/css/style.css">
</head>

<body>
<h1>This page does not exist.</h1>
<hr>
<a href="index.php?page">Retour à l'accueil</a>
</body>

</html>