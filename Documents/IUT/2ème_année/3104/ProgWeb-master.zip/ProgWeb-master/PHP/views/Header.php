<div id="header">
    <div class="return">
        <a href="index.php">&#x21A2</a>
    </div>
    <div class="title">
        <h1>SportTrack</h1>
    </div>
</div>