<!DOCTYPE html>
<head>
    <title>SportTrack</title>
    <link  rel="stylesheet" href="../public/css/style.css">
</head>

<body>
    <?php include('Header.php');?>
    <form>
        <div>
            <label for="activityFile"> Upload your activity file</label>
        </div>
        <input id="activityFile" name="activityFile" type="file">

    </form>
</body>