<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Déconnexion</title>
</head>
<body>
   <h1>Vous avez bien été déconnecté(e)</h1>
   <hr>
   <a href="index.php?page=user_connect_form">Connexion</a>
   <a href="index.php?page=user_connect_form">Créer un compte</a>
</body>
</html>